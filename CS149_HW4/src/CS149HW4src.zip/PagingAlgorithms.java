import java.util.ArrayList;

/**
 * @author Andy Wang
 * @author Kunal Palwankar
 * @author Julian Zabala
 * @author David Pham
 * Algorithm object to simulate paging algorithms and print out
 * the result
 */
public class PagingAlgorithms {

    public PagingAlgorithms(){

    }

    public void firstInFirstOut(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add FIFO algorithm here
    }

    public void leastRecentlyUsed(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add LRU algorithm here
    }

    public void leastFrequentlyUsed(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add LFU algorithm here
    }

    public void mostRecentlyUsed(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add MRU algorithm here
    }
}
