/**
 * Created by Andy on 2/26/2015.
 */
public class Process {

    private int size;
    private int duration;

    public Process(int size, int duration) {
        this.size = size;
        this.duration = duration;
    }

    public int getSize() {
        return size;
    }

    public int getDuration() {
        return duration;
    }
}
