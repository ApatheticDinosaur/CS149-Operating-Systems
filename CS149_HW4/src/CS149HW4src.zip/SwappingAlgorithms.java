import java.util.ArrayList;

/**
 * @author Andy Wang
 * @author Kunal Palwankar
 * @author Julian Zabala
 * @author David Pham
 * A swapping algorithms object that will be used to print the result of
 * each algorithm
 */
public class SwappingAlgorithms {

    public SwappingAlgorithms(){

    }

    public void firstFit(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add first fit algorithm here
    }

    public void nextFit(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add next fit algorithm here
    }

    public void bestFit(ArrayList<Process> p) {
        ArrayList<Process> processes = p;
        //TODO: Add best fit algorithm here
    }

}
